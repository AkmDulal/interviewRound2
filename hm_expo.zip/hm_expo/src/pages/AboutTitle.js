import React, { Component } from 'react';

class AboutTitle extends Component {
    render() {
        return (
            <div>
                <h1>  AboutTitle AboutTitle </h1>
            </div>
        );
    }
}

export default AboutTitle;