import React, { Component } from 'react';

class AboutDetails extends Component {
    render() {
        return (
            <div>
                <h1> About Details Area  </h1>
            </div>
        );
    }
}

export default AboutDetails;